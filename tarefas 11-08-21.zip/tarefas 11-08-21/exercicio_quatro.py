# Python: Avançando na Orientação a Objetos.
# Faça um sistema de cadastro de pessoas que realize o cadastro de 10 pessoas
# e quando solicitado mostre o valor da pessoa solicitada.
# Utilize Classe e sistemas de repetição para te auxiliar.
# Nome, email, RG, nacionalidade, nascimento
import random


class Cadastro:
    def __init__(self, nome, nacionalidade, dia_nascimento, mes_nascimento, ano_nascimento, titular):
        self._nome = nome.title()
        self._nacionalidade = nacionalidade
        self._data_nascimento = f'{dia_nascimento}/{mes_nascimento}/{ano_nascimento}'
        if not titular:
            self._titular = random.randrange(1000, 10000)
        else:
            self._titular = titular

    @property
    def nome(self):
        return self._nome

    @nome.setter
    def nome(self, novo_nome):
        self._nome = novo_nome.title()

    @property
    def data_nascimento(self):
        return self._data_nascimento

    def __str__(self):
        return f'Titular n° {self._titular}: {self._nome}\n' \
               f'País de origem: {self._nacionalidade}\n' \
               f'Data de nascimento: {self._data_nascimento}\n'


user_1 = Cadastro('Lucas Cordeiro', 'Brasil', 8, 12, 2004, '')
user_2 = Cadastro('Waléria Cordeiro', 'Brasil', 7, 2, 2017, '')
user_3 = Cadastro('Valquíria Cordeiro', 'Brasil', 11, 10, 2020, '')
user_4 = Cadastro('Camila Daniella', 'Brasil', 28, 7, 1994, '')
user_5 = Cadastro('Vitória Pereira', 'Brasil', 4, 1, 2006, '')
user_6 = Cadastro('João Vitor', 'Brasil', 13, 8, 2010, '')
user_7 = Cadastro('Jane Doe', 'Estados Unidos', 2, 10, 1962, '')
user_8 = Cadastro('Will Treaty', 'Inglaterra', 5, 4, 628, '')
user_9 = Cadastro('John', 'Eridanus II', 7, 3, 2511, 117)
user_10 = Cadastro('Falta de Criatividade', 'Minha mente', 1, 1, '13.000.000.000 A.C', '000')

usuarios = [user_1, user_2, user_3, user_4, user_5, user_6, user_7, user_8, user_9, user_10]

for cadastro in usuarios:
    print(cadastro)
