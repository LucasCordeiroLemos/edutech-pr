# As Organizações Tabajara resolveram dar um aumento de salário aos seus colaboradores
# e lhe contraram para desenvolver o programa que calculará os reajustes.

# Faça um programa que recebe o salário de um colaborador
# e o reajuste segundo o seguinte critério, baseado no salário atual:

# Salários até R$ 280,00 (incluindo): aumento de 20%
# Salários entre R$ 280,00 e R$ 700,00: aumento de 15%
# Salários entre R$ 700,00 e R$ 1500,00: aumento de 10%
# Salários de R$ 1500,00 em diante: aumento de 5%

# Após o aumento ser realizado, informe na tela:

# O salário antes do reajuste;
# O percentual de aumento aplicado;
# O valor do aumento;
# O novo salário, após o aumento.

def reajuste_salarial(salario_antigo):
    percentual = int
    if salario_antigo <= 280:
        percentual = 0.2
    elif 280 < salario_antigo <= 700:
        percentual = 0.15
    elif 700 < salario_antigo <= 1500:
        percentual = 0.1
    elif salario_antigo > 1500:
        percentual = 0.05

    reajuste = salario_antigo * percentual
    novo_salario = salario_antigo + reajuste

    print(f"O salário antigo era de {salario_antigo} reais.")
    print(f"O percentual aplicado foi de {percentual * 100}%.")
    print(f"O valor do aumento foi de {reajuste} reais.")
    print(f"O novo salário deste funcionário é de {novo_salario} reais.")

# Antes, as condições nas linhas 23 e 25 eram formatadas assim:

# elif salario_antigo > 280 and salario_antigo <= 700:

# E funciona, porque se o salário é maior que um número
# e menor que outro, dá para encaixar ele nessa faixa específica.
# Mas eu acabei alterando o código seguindo uma sugestão de simplificação do PyCharm.
# E, sendo honesto, tá bem melhor agora. Mais bonito.
