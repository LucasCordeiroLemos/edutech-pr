# 1 - Faça um Programa que peça dois números e imprima a soma.

def soma_1():
    n1 = input("Digite o primeiro número: ")
    n2 = input("Digite o segundo número: ")
    print(f"A soma entre {n1} e {n2} é {n1 + n2}.")

# alternativamente:


def soma_2(n1, n2):
    print(f"A soma entre {n1} e {n2} é {n1 + n2}.")

# 2 - Faça um Programa que peça as 4 notas bimestrais e mostre a média.


def media_notas_1():
    nota1 = float(input("Digite a nota do primeiro bimestre: "))
    nota2 = float(input("Digite a nota do segundo bimestre: "))
    nota3 = float(input("Digite a nota do terceiro bimestre: "))
    nota4 = float(input("Digite a nota do quarto bimestre: "))
    media = (nota1 + nota2 + nota3 + nota4) / 4
    print(f"A média das suas notas é {media :4.1f}")

# alternativamente:


def media_notas_2(nota1, nota2, nota3, nota4):
    media = (nota1 + nota2 + nota3 + nota4) / 4
    print(f"A média das suas notas é {media :4.1f}")

# media_notas_2(6, 7.6, 8.4, 5.8)
# A média das suas notas é 7.0 (arredondado de 6,95)

# As funções soma_1 e media_notas_1 são códigos que não precisavam ser declarados em função para funcionar.
# Eu usei as funções pra separar melhor o código dentro de um arquivo.

# Decidi criar duas funções para cada exercício porque
# a segunda ideia é melhor de ser usada se fosse chamada pelo console,
# mas é menos "amigável com o usuário" se por algum motivo algum dia eu
# precisasse escrever um código que peça dois números para somar os dois.
