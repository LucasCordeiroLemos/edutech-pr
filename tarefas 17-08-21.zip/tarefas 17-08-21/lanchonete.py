# Criar uma código fonte que representa uma lanchonete,
# o usuário terá de digitar um código e a quantidade,
# no final o programa deverá mostrar o resultado da compra.

# print('Especificacao   Codigo  Preco')
# print('Cachorro Quente 100     R$ 1,20')
# print('Bauru Simples   101     R$ 1,30')
# print('Bauru com Ovo   102     R$ 1,50')
# print('Hamburger       103     R$ 1,20')
# print('Cheeseburger    104     R$ 1,30')
# print('Refrigerante    105     R$ 1,00')


cach_quen = ['Cachorro Quente', 1.20]
baur_simp = ['Bauru Simples', 1.30]
baur_ovo = ['Bauru com Ovo', 1.50]
hamb = ['Hamburguer', 1.20]
ches_burg = ['Cheeseburguer', 1.30]
refri = ['Refrigerante', 1.00]

produtos = {100: cach_quen, 101: baur_simp, 102: baur_ovo, 103: hamb, 104: ches_burg, 105: refri}

for produto in produtos:
    print(f'N° {produto}: {produtos[produto][0]} - R${produtos[produto][1]}')

while True:
    pedido = int(input('Faça seu pedido: '))
    if pedido in produtos:
        quantidade = int(input(f'{produtos[pedido][0]} foi selecionado. Especifique a quantidade: '))
        valor = float(produtos[pedido][1] * quantidade)
        print(f'O valor desse pedido é de R${valor :4.2f}')
        break
    else:
        print('Este código de produto é inválido. Tente novamente')
