# Criar um código fonte que representa a urna eletrônica de 4 candidatos,
# votos nulos e em branco, cada candidato tem 1 numero para ser votado,
# o programa deve receber esse número e no final mostrar quem foi o vencedor,
# para encerrar a votação a pessoa terá de digitar 0.

print('URNA ELETRONICA')
print('1 - João')
print('2 - José')
print('3 - Jacó')
print('4 - Jobe')
print('5 - Voto Nulo')
print('6 - Voto em Branco')
print('0 - Encerrar votação')

joao = 0
jose = 0
jaco = 0
jobe = 0
nulo = 0
branco = 0

candidatos = {1: joao, 2: jose, 3: jaco, 4: jobe, 5: nulo, 6: branco}

while True:
    voto = int(input('Vote: '))
    if voto:
        candidatos[voto] += 1
    elif not voto:
        break

print(f'\nCandidato: João - Votos: {candidatos[1]}')
print(f'Candidato: José - Votos: {candidatos[2]}')
print(f'Candidato: Jacó - Votos: {candidatos[3]}')
print(f'Candidato: Jobe - Votos: {candidatos[4]}')
print(f'Votos Nulos: {candidatos[5]}')
print(f'Votos em Branco: {candidatos[6]}')
